/*Basic Calculator:
○ Write a program that performs basic mathematical operations (addition,
subtraction, multiplication, division) based on user input.
○ Each operation should be performed in its own function, and the program should
prompt the user to choose which operation to perform.*/

import java.util.Scanner;

public class BasicCalculator {

    // Function to add two numbers
    private static double add(double a, double b) {
        return a + b;
    }

    // Function to subtract two numbers
    private static double subtract(double a, double b) {
        return a - b;
    }
}
    // Function to multiply two numbers
