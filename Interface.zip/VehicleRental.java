package OOPS.Interface;
interface Rentable {
    void rent();
    void returnVehicle();
}

class Car implements Rentable {
    public void rent() { System.out.println("Car rented"); }
    public void returnVehicle() { System.out.println("Car returned"); }
}

class Bike implements Rentable {
    public void rent() { System.out.println("Bike rented"); }
    public void returnVehicle() { System.out.println("Bike returned"); }
}

class Bus implements Rentable {
    public void rent() { System.out.println("Bus rented"); }
    public void returnVehicle() { System.out.println("Bus returned"); }
}

public class VehicleRental {
    public static void main(String[] args) {
        Rentable r = new Car(); r.rent(); r.returnVehicle();
        r = new Bike(); r.rent(); r.returnVehicle();
        r = new Bus(); r.rent(); r.returnVehicle();
    }
}
